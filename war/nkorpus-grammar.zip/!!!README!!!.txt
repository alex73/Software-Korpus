﻿

Лексіка-граматычная база для Беларускага N-корпуса (http://korpus.ns360.info/)

Зборка ад 14.08.2013

База даступная на ўмовах ліцэнзіі CC BY-SA 3.0 (http://creativecommons.org/licenses/by-sa/3.0/)

Заўвагі і прапановы дасылайце на bnkorpus@gmail.com
