Belarusian spelling dictionary by official orthography rules 2008

Created from Belarusian Grammar Database (http://bnkorpus.info)
Authors: Symon Kakora <symonkakora@gmail.com>, Aleś Bułojčyk <alex73mail@gmail.com>, Uladź Koščanka <koshul@gmail.com>

This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License (http://creativecommons.org/licenses/by-sa/4.0/).
Also, can redistribute it and/or modify it under the terms of the LGPLv3.

Belarusian spelling dictionary is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Belarusian spelling dictionary is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with Belarusian spelling dictionary. If not, see <http://www.gnu.org/licenses/>.
