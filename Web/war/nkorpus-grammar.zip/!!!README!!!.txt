﻿

Лексіка-граматычная база для Беларускага N-корпуса (http://bnkorpus.info/)

Зборка ад 10.08.2016

База даступная на ўмовах ліцэнзіі Creative Commons Attribution-ShareAlike 4.0 International License (http://creativecommons.org/licenses/by-sa/4.0/)
Аўтары: Symon Kakora <symonkakora@gmail.com>, Aleś Bułojčyk <alex73mail@gmail.com>, Uladź Koščanka <koshul@gmail.com>

Заўвагі і прапановы дасылайце на bnkorpus@gmail.com
